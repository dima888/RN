package rn.p1.pop3;

import static org.junit.Assert.*;

import org.junit.Test;

import rn.p1.pop3.enums.Command;

public class CommandTest {

	@Test
	public void test() {
		assertEquals(Command.OK.getCommand(), "+OK");	
		assertEquals(Command.USER.getCommand(),"USER");
		
		System.out.println("Unterstuetzte Befehle:");
		for (Command c : Command.values()) {
			System.out.println(c.getCommand());			
		}
	}

}
