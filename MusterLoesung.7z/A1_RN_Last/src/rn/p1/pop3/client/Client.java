package rn.p1.pop3.client;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import rn.p1.pop3.conf.Configuration;
import rn.p1.pop3.data.DataServices;
import rn.p1.pop3.data.Logger;
import rn.p1.pop3.data.MailAccount;
import rn.p1.pop3.data.UserAccount;

public class Client extends Thread {
	
	public void run() {
		Map<String, UserAccount> users = DataServices.getAllUsers();
		int sessionId = 0;
		try {
			Logger logger = new Logger("pop3client");			
			while (true) { 
				for (UserAccount user : users.values()) {
					for (MailAccount mailAccount : user.getMailAccounts()) {
						ClientSession clientSession = new ClientSession(++sessionId, user, mailAccount, logger);
						clientSession.start();
					}
				}
				try {
					TimeUnit.SECONDS.sleep(Configuration.POOLING_INTERVAL_IN_SECONDS);
				} catch (InterruptedException e) {			
					e.printStackTrace();
				}
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		
	}
}
