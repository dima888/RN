package rn.p1.pop3.client;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.StringTokenizer;

import rn.p1.pop3.data.DataServices;
import rn.p1.pop3.data.Logger;
import rn.p1.pop3.data.MailAccount;
import rn.p1.pop3.data.Message;
import rn.p1.pop3.data.UserAccount;
import rn.p1.pop3.enums.Command;
import rn.p1.pop3.exception.NotExpectedResponseException;

public class ClientSession extends Thread {

	private Socket clientSocket; // TCP-Standard-Socketklasse

	private DataOutputStream outToServer; // Ausgabestream zum Server
	private BufferedReader inFromServer; // Eingabestream vom Server

	private UserAccount user;
	private MailAccount mailAccount;

	private int sessionId;

	private Logger logger;

	public ClientSession(int sessionId, UserAccount user,
			MailAccount mailAccount, Logger logger) {
		setSessionId(sessionId);
		setUser(user);
		setMailAccount(mailAccount);
		setLogger(logger);
	}

	public void run() {
		if (!mailAccount.isBusy()) {
			mailAccount.setBusy(true);
			/* Ab Java 7: try-with-resources mit automat. close benutzen! */
			try {
				/* Socket erzeugen --> Verbindungsaufbau mit dem Server */
				clientSocket = new Socket(mailAccount.getAddressPop3Server(),
						mailAccount.getPort()); 

				/* Socket-Basisstreams durch spezielle Streams filtern */
				outToServer = new DataOutputStream(
						clientSocket.getOutputStream());
				inFromServer = new BufferedReader(new InputStreamReader(
						clientSocket.getInputStream()));
				/* the POP3 server issues a one line greeting. */
				assertThatResponseOk(readFromServer());
				/* AUTHORIZATION State */
				/* Anmeldung USERNAME */
				writeToServer(Command.USER
						.getCommand(mailAccount.getUsername()));
				assertThatResponseOk(readFromServer());

				/* Anmeldung PASSWORD */
				writeToServer(Command.PASS
						.getCommand(mailAccount.getPassword()));
				assertThatResponseOk(readFromServer());

				/* TRANSACTION State */
				writeToServer(Command.STAT.getCommand());
				String response = readFromServer();
				assertThatResponseOk(response);

				String parameters = Command.OK.getInputParameter(response);
				StringTokenizer st = new StringTokenizer(parameters);

				int newMessages = Integer.parseInt(st.nextToken());

				for (int i = 0; i < newMessages; i++) {
					writeToServer(Command.RETR.getCommand(i + 1));
					assertThatResponseOk(readFromServer());

					String mail = readMessageFromServer();
					
					mailAccount.addMessage(new Message(mail));

					writeToServer(Command.DELE.getCommand(i + 1));
					assertThatResponseOk(readFromServer());
				}

				writeToServer(Command.QUIT.getCommand());
				assertThatResponseOk(readFromServer());

				DataServices.saveMessages(user, mailAccount);

				/* Socket-Streams schließen --> Verbindungsabbau */
				clientSocket.close();

			} catch (IOException e) {
				System.err.println("Connection aborted by server!");
				e.printStackTrace();
			} catch (NotExpectedResponseException ex) {
				mailAccount.getMessages().clear();
				/* Socket-Streams schließen --> Verbindungsabbau */
				try {
					clientSocket.close();
				} catch (IOException e) {
					System.err.println("Connection aborted by server!");
					e.printStackTrace();
				}
			} finally {
				System.out.println("TCP Client stopped!");
				mailAccount.setBusy(false);
			}
		}
	}

	private void assertThatResponseOk(String response)
			throws NotExpectedResponseException {
		if (!Command.OK.isCommand(response)) {
			throw new NotExpectedResponseException("OK Response expected");
		}
	}

	private void writeToServer(String request) throws IOException {
		/* Sende eine Zeile zum Server */
		outToServer.writeBytes(request + '\n');
		System.out.println("TCP Client has sent the message: " + request);
		logger.log(sessionId, "TCP Client has sent the message: " + request);
	}

	private String readFromServer() throws IOException {
		/* Lies die Antwort (reply) vom Server */
		String reply = inFromServer.readLine();
		System.out.println("TCP Client got from Server: " + reply);
		logger.log(sessionId, "TCP Client got from Server: " + reply);
		return reply;
	}

	private String readMessageFromServer() throws IOException {
		StringBuffer originalMessage = new StringBuffer();
		StringBuffer result = new StringBuffer();
		String line = null;
		do {
			line = inFromServer.readLine();
			originalMessage.append(line + "\r\n");
			if (line.startsWith("..")) {
				result.append(line.substring(1) + "\r\n");
			} else if (!line.equals(".")) {
				result.append(line + "\r\n");
			}
		} while (!line.equals("."));
		logger.log(sessionId, originalMessage.toString());
		return result.toString();
	}

	public int getSessionId() {
		return sessionId;
	}

	public UserAccount getUser() {
		return user;
	}

	public void setUser(UserAccount user) {
		this.user = user;
	}

	public MailAccount getMailAccount() {
		return mailAccount;
	}

	public void setMailAccount(MailAccount mailAccount) {
		this.mailAccount = mailAccount;
	}

	public void setSessionId(int sessionId) {
		this.sessionId = sessionId;
	}

	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}
}
