package rn.p1.pop3.server;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

import rn.p1.pop3.data.Logger;
import rn.p1.pop3.data.UserAccount;
import rn.p1.pop3.enums.Command;
import rn.p1.pop3.enums.Pop3State;

public class ServerSession extends Thread {
	
	//	eindeutige ID der Session
	private int sessionId;
	
	/*
	 * Arbeitsthread, der eine existierende Socket-Verbindung zur Bearbeitung
	 * erhält
	 */
	private Socket socket;

	
	private BufferedReader inFromClient;
	private DataOutputStream outToClient;

	boolean serviceRequested = true; // Arbeitsthread beenden?

	private UserAccount userAccount;
	
	private Pop3State currentPop3state = Pop3State.AUTHORIZATION;

	private Logger logger;
	
	public ServerSession(int sessionId, Socket socket, Logger logger) {
		this.setSessionId(sessionId);
		this.setSocket(socket);
		this.setLogger(logger);
	}
	  
	public void run() {
		String commandFromClient;

		System.out.println("TCP Server Thread " + getSessionId()
				+ " is running until QUIT is received!");		
		try {
			/* Socket-Basisstreams durch spezielle Streams filtern */
			inFromClient = new BufferedReader(new InputStreamReader(
					getSocket().getInputStream()));
			outToClient = new DataOutputStream(getSocket().getOutputStream());
			
			//	Begrüßung senden
			writeToClient(Command.OK.getCommand("Server ready"));
			
			while (serviceRequested) {
				
				/* String vom Client empfangen */
				commandFromClient = readFromClient();
												
				if (commandFromClient!=null) {
					boolean commandFound = false;
					for (Command command : currentPop3state.getCommands()) {
						if (command.isCommand(commandFromClient)) {
							// Client antworten 
							writeToClient(command.handleInput(commandFromClient, this));
							commandFound = true;							
						}						
					}
					
					if (!commandFound) {
						writeToClient(Command.ERR.getCommand());
					}
				}else{
					serviceRequested = false;
				}
			}

			/* Socket-Streams schließen --> Verbindungsabbau */
			getSocket().close();
		} catch (IOException e) {
			System.err.println("Connection aborted by client!");
		}
		System.out.println("TCP Server Thread " + getSessionId() + " stopped!");
	}

	private String readFromClient() throws IOException {
		/* Lies die nächste Anfrage-Zeile (request) vom Client */
		String request = inFromClient.readLine();
		System.out.println("TCP Server Thread detected job: " + request);
		logger.log(sessionId, "TCP Server Thread detected job: " + request);
		return request;
	}

	private void writeToClient(String reply) throws IOException {
		/* Sende den String als Antwortzeile (mit newline) zum Client */
		outToClient.writeBytes(reply + '\n');
		System.out.println("TCP Server Thread " + getSessionId()
				+ " has written the message: " + reply);
		logger.log(sessionId, "TCP Server Thread has written the message: " + reply);
	}

	public UserAccount getUserAccount() {
		return userAccount;
	}

	public void setUserAccount(UserAccount userAccount) {
		this.userAccount = userAccount;
	}

	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

	public int getSessionId() {
		return sessionId;
	}

	public void setSessionId(int sessionId) {
		this.sessionId = sessionId;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}
	
	public boolean isServiceRequested() {
		return serviceRequested;
	}

	public void setServiceRequested(boolean serviceRequested) {
		this.serviceRequested = serviceRequested;
	}

	public Pop3State getCurrentPop3state() {
		return currentPop3state;
	}

	public void setCurrentPop3state(Pop3State currentPop3state) {
		this.currentPop3state = currentPop3state;
	}
}
