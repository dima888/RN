package rn.p1.pop3.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import rn.p1.pop3.conf.Configuration;
import rn.p1.pop3.data.Logger;

public class Server extends Thread {

	public void run() {
		ServerSocket listenerSocket; 	// TCP-Server-Socketklasse
		Socket connectionSocket; 		// TCP-Standard-Socketklasse 
		int sessionId = 0; 

		try {
			Logger logger = new Logger("pop3server");	
			
			/* Server-Socket erzeugen */
			listenerSocket = new ServerSocket(Configuration.SERVER_PORT);

			while (true) { // Server laufen IMMER
				System.out
						.println("TCP Server: Waiting for connection - listening TCP port "
								+ Configuration.SERVER_PORT);
				/*
				 * Blockiert auf Verbindungsanfrage warten --> nach
				 * Verbindungsaufbau Standard-Socket erzeugen und
				 * connectionSocket zuweisen
				 */
				connectionSocket = listenerSocket.accept();
 
				/* Neuen Arbeits-Thread erzeugen und den Socket übergeben */
				(new ServerSession(++sessionId, connectionSocket, logger)).start();
			}					
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

}
