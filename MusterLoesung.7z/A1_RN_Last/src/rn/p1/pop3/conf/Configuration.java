package rn.p1.pop3.conf;


public class Configuration {

	/* Server, der Verbindungsanfragen entgegennimmt */
	public static final int SERVER_PORT = 11000;
	
	/* */
	public static final int POOLING_INTERVAL_IN_SECONDS = 30;
	
	/* Verzeichnis für eingehende E-Mails*/
	public static final String MAIL_FOLDER_NAME = "./mail/users";
}
