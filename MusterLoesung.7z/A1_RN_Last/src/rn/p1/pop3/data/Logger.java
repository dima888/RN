package rn.p1.pop3.data;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Logger {

    File f;
    FileWriter fw;
    BufferedWriter bw;

    public Logger(String hostName) throws IOException {
        f = new File(hostName + ".log");
        fw = new FileWriter(f);
        bw = new BufferedWriter(fw);
    }

    public synchronized void log(int sessionId, String toLog) {
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yy 'um' HH:mm:ss ");
        Date currentTime = new Date();
             
        try {
        	bw.newLine();
			bw.write("[" + sessionId + "] " + formatter.format(currentTime)+toLog);
			bw.flush();
		} catch (IOException e) {		
			e.printStackTrace();
		}        
    }
    public void close() throws IOException{        
        fw.close();
    }
}