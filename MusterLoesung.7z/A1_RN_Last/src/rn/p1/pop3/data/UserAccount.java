package rn.p1.pop3.data;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import rn.p1.pop3.conf.Configuration;
import rn.p1.pop3.exception.MessageDeleteException;

public class UserAccount {
	private String username;
	private String password;
	
	private List<MailAccount> mailAccounts = new ArrayList<MailAccount>();
		
	private List<Message> allMessages = new ArrayList<Message>();
	
	public List<MailAccount> getMailAccounts() {
		return mailAccounts;
	}

	public void setMailAccounts(List<MailAccount> mailAccounts) {
		this.mailAccounts = mailAccounts;
	}

	public UserAccount(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void addMailAccount(MailAccount mailAccount) {
		mailAccounts.add(mailAccount);
	}

	public List<Message> getAllMessages() {
		return allMessages;
	}

	public void setAllMessages(List<Message> allMessages) {
		this.allMessages = allMessages;
	}
	
	public void readAllMessages() {		
		allMessages = new ArrayList<Message>();
		File userMailFolder = new File(Configuration.MAIL_FOLDER_NAME + "/" + username);
		File[] emails = userMailFolder.listFiles();
		if (emails != null) { 
			for (int i = 0; i < emails.length; i++) {		
				String output;
				try {
					output = new Scanner( emails[i]).useDelimiter("\\Z").next();
					allMessages.add(new Message(output, emails[i].getName()));
				} catch (FileNotFoundException e) {				
					e.printStackTrace();
				}		        				
			}
		}					
	}
	
	public void deleteAllMarkedMessages() throws MessageDeleteException {
		for (Message message : allMessages) {
			if (message.isMarkedAsDeleted()) {
				if (!new File(Configuration.MAIL_FOLDER_NAME + "/" + username + "/" + message.getUuid()).delete()) {
					throw new MessageDeleteException("Cannot delete a message");
				}
			}
		}
	}
}