package rn.p1.pop3.data;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import rn.p1.pop3.conf.Configuration;

public class DataServices {
	
	private static Map<String,UserAccount> users;
	
	
	public static Map<String,UserAccount> getAllUsers() {

		if (users == null) {
			users = new HashMap<String,UserAccount>();
				UserAccount user1 = new UserAccount("test13102013@127.0.0.1","123");
				user1.addMailAccount(new MailAccount("pop.gmx.net", 110, "hawrn1@gmx.de", "haw123456"));				
				user1.addMailAccount(new MailAccount("pop.gmx.net", 110, "hawrn2@gmx.de", "haw123456")); 
				users.put(user1.getUsername(),user1);
				
			/*
				UserAccount user2 = new UserAccount("test1@127.0.0.1","123");				
				user2.addMailAccount(new MailAccount("pop.gmx.net", 110, "bairn2@gmx.de", "egal1234"));
				users.put(user2.getUsername(),user2);
						*/
			// TODO: weitere Accounts
		}
		
		
		return users;
	}
	
	public static void saveMessages(UserAccount userAccount, MailAccount mailAccount) throws FileNotFoundException {
		String userFolder = Configuration.MAIL_FOLDER_NAME+"/"+userAccount.getUsername();
		File file = new File(userFolder+"/folder");
		file.getParentFile().mkdirs();
		
		for (Message message : mailAccount.getMessages()) {
			PrintWriter out = new PrintWriter(userFolder+"/"+message.getUuid());		
			out.print(message.getContent());
			out.close();
		}
		
	}
}
