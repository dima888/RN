package rn.p1.pop3.data;

import java.util.UUID;

public class Message {
	private String uuid;
	private String content;
	private boolean markedAsDeleted;


	public Message(String content) {
		this.setContent(content);
		this.setUuid(UUID.randomUUID().toString());
	}
	
	public Message(String content, String uuid) {
		this.setContent(content);
		this.setUuid(uuid);
	}

	public long getMessageSize() {
		if (content != null) {
			return content.length();
		}
		return 0;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public String getEscapedContent() {
		StringBuilder sb = new StringBuilder();
		String[] tokens = content.split("\r\n");
		for (String token : tokens) {
			if (token.startsWith("."))
				token = "." + token; 
			sb.append(token+"\r\n");
		}
		sb.append(".");
		return sb.toString(); 
	}

	public boolean isMarkedAsDeleted() {
		return markedAsDeleted;
	}

	public void setMarkedAsDeleted(boolean markedAsDeleted) {
		this.markedAsDeleted = markedAsDeleted;
	}

}
