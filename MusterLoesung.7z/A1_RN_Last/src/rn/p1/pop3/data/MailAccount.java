package rn.p1.pop3.data;

import java.util.ArrayList;
import java.util.List;

public class MailAccount {
	private String addressPop3Server;
	private String username;
	private String password;
	private int port;
	
	private boolean busy = false;
	
	private List<Message> messages = new ArrayList<Message>();
	
	public MailAccount(String addressPop3Server, int port, String username,
			String password) {
		super();
		this.addressPop3Server = addressPop3Server;
		this.setPort(port);
		this.username = username;
		this.password = password;
	}


	public String getAddressPop3Server() {
		return addressPop3Server;
	}


	public void setAddressPop3Server(String addressPop3Server) {
		this.addressPop3Server = addressPop3Server;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public int getPort() {
		return port;
	}


	public void setPort(int port) {
		this.port = port;
	}


	public boolean isBusy() {
		return busy;
	}


	public void setBusy(boolean busy) {
		this.busy = busy;
	}


	public List<Message> getMessages() {
		return messages;
	}


	public void setMessages(List<Message> messages) {
		this.messages = messages;
	}
	
	public void addMessage(Message message) {
		messages.add(message);
	}
	
}
