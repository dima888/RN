package rn.p1.pop3.exception;

public class NotExpectedResponseException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public NotExpectedResponseException(String message) {
		super(message);
	}
}
