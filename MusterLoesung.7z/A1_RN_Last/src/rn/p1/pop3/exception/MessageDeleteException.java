package rn.p1.pop3.exception;

public class MessageDeleteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageDeleteException(String message) {
		super(message);
	}


}
