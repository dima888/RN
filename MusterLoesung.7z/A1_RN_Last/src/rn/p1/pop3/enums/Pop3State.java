package rn.p1.pop3.enums;

public enum Pop3State {
			//The client may issue any of the following POP3 commands repeatedly. 
	AUTHORIZATION(Command.USER, Command.PASS, Command.QUIT), 
	TRANSACTION(Command.STAT, Command.LIST, Command.RETR, 
			Command.DELE, Command.NOOP, Command.RSET, Command.UIDL, Command.QUIT), 
	UPDATE(Command.QUIT);

	private Command[] commands;

	private Pop3State(Command... commands) {
		this.setCommands(commands);
	}

	public Command[] getCommands() {
		return commands;
	}

	public void setCommands(Command[] commands) {
		this.commands = commands;
	}

}
