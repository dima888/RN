package rn.p1.pop3.enums;

import java.util.List;

import rn.p1.pop3.data.DataServices;
import rn.p1.pop3.data.Message;
import rn.p1.pop3.data.UserAccount;
import rn.p1.pop3.exception.MessageDeleteException;
import rn.p1.pop3.server.ServerSession;

public enum Command {
	USER, 
	PASS, 
	QUIT, 
	STAT, 
	LIST, 
	RETR, 
	DELE, 
	NOOP, 
	RSET, 
	UIDL, 
	OK("+OK"), 
	ERR("-ERR");

	private String command;

	private Command() {
		this.command = this.toString();
	}

	private Command(String command) {
		this.setCommand(command);
	}

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	public String getCommand(Object arg) {
		return getCommand() + " " + arg.toString();
	}

	public String getInputParameter(String input) {
		if (input.length() > this.getCommand().length() + 1) {
			return input.substring(this.getCommand().length() + 1,
					input.length());
		}
		return "";
	}

	public boolean isCommand(String input) {
		if (input != null && input.toUpperCase().startsWith(getCommand())) {
			return true;
		}
		return false;
	}

	public String handleInput(String inputWithCommand, ServerSession session) {
		UserAccount userAccount = null;
		String input = getInputParameter(inputWithCommand);
		List<Message> messages = null;
		Message message = null;
		int messageNr = 0;
		if (session.getCurrentPop3state().equals(Pop3State.TRANSACTION)) {
			userAccount = session.getUserAccount();
			messages = session.getUserAccount().getAllMessages();
		}
		switch (this) {
		case USER:
			userAccount = DataServices.getAllUsers().get(input);

			if (userAccount != null) {
				session.setUserAccount(userAccount);
				return OK.getCommand();
			} else {
				return ERR.getCommand();
			}
		case PASS:
			userAccount = session.getUserAccount();
			if (userAccount != null && userAccount.getPassword().equals(input)) {
				session.setCurrentPop3state(Pop3State.TRANSACTION);
				userAccount.readAllMessages();
				return OK.getCommand();
			} else {
				/*
				 * After returning a negative status indicator, the server close
				 * the connection.
				 */
				session.setServiceRequested(false);
				return ERR.getCommand();
			}

			/*
			 * STAT Arguments: none
			 */
		case STAT:
			int size = 0;
			int anzahlMessages = 0;
			for (Message messagesIter : messages) {
				// messages marked as deleted are not counted in either total.
				if (!messagesIter.isMarkedAsDeleted()) {
					size += messagesIter.getMessageSize();
					anzahlMessages++;
				}
			}
			return OK.getCommand(anzahlMessages + " " + size);
			/*
			 * LIST [msg] Arguments: a message-number (optional), which, if
			 * present, may NOT refer to a message marked as deleted
			 */
		case LIST:
			if (!"".equals(input)) {
				// eine bestimmte Nachricht auflisten
				try {
					messageNr = Integer.parseInt(input);
				} catch (Exception e) {
					// keine zahl
					return ERR.getCommand(" invalid sequence number: \""
							+ input + "\"");
				}
				// wenn nachricht als Gelöscht markiekt, wird die nicht angezeig
				if (messages.get(messageNr - 1).isMarkedAsDeleted())
					return ERR.getCommand(" mail with sequence number "
							+ messageNr + " was deleted earlier ");

				return OK.getCommand((messageNr) + " "
						+ messages.get(messageNr - 1).getMessageSize());

			} else {
				// alle Nachrichten auflisten
				StringBuilder sb = new StringBuilder();
				/*
				 * The first message in the maildrop is assigned a
				 * message-number of"1", the second is assigned "2", and so on,
				 * so that the nth messagein a maildrop is assigned a
				 * message-number of "n".
				 */
				for (int i = 0; i < messages.size(); i++) {
					// nur Nachrichten die nicht als Gelöscht markiert
					if (!messages.get(i).isMarkedAsDeleted()) {
						sb.append("\r\n" + (i + 1) + " "
								+ messages.get(i).getMessageSize());
					}
				}
				// Ende von mehrzeilige ausgabe
				sb.append("\r\n.");
				return OK.getCommand(sb.toString());
			}
			/*
			 * UIDL [msg] Arguments: a message-number (optional), which, if
			 * present, may NOT refer to a message marked as deleted
			 */
		case UIDL:
			if (!"".equals(input)) {
				try {
					messageNr = Integer.parseInt(input);
				} catch (Exception e) {
					return ERR.getCommand(" invalid sequence number: \""
							+ input + "\"");
				}
				message = messages.get(messageNr);
				if (message.isMarkedAsDeleted()) {
					return ERR.getCommand("mail with sequence number "
							+ messageNr + " was deleted earlier");
				}
				return OK.getCommand((messageNr) + " "
						+ messages.get(messageNr - 1).getUuid());
			} else {
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < messages.size(); i++) {
					if (!messages.get(i).isMarkedAsDeleted()) {
						sb.append("\r\n" + (i + 1) + " "
								+ messages.get(i).getUuid());
					}
				}
				sb.append("\r\n.");
				return OK.getCommand(sb.toString());
			}

			/*
			 * RETR msg Arguments: a message-number (required) which may NOT
			 * refer to a message marked as deleted
			 */
		case RETR:
			try {
				messageNr = Integer.parseInt(input);
			} catch (Exception e) {
				return ERR.getCommand(" invalid sequence number: \"" + input
						+ "\"");
			}

			if (messages.get(messageNr - 1).isMarkedAsDeleted())
				return ERR.getCommand(" mail with sequence number " + messageNr
						+ " was deleted earlier ");

			message = messages.get(messageNr - 1);
			return OK.getCommand("\r\n" + message.getEscapedContent());

			/*
			 * DELE msg Arguments: a message-number (required) which may NOT
			 * refer to a message marked as deleted
			 */
		case DELE:
			try {
				messageNr = Integer.parseInt(input);
			} catch (Exception e) {
				return ERR.getCommand(" invalid sequence number: \"" + input
						+ "\"");
			}
			message = messages.get(messageNr - 1);
			if (message.isMarkedAsDeleted())
				return ERR.getCommand("mail with sequence number " + messageNr
						+ " was deleted earlier");
			message.setMarkedAsDeleted(true);
			return OK.getCommand("Message marked as deleted");
			
		case NOOP:
			return OK.getCommand();
				
		case QUIT:
			session.setServiceRequested(false);
			if (session.getCurrentPop3state().equals(Pop3State.TRANSACTION)) {
				session.setCurrentPop3state(Pop3State.UPDATE);
				try {
					userAccount.deleteAllMarkedMessages();
					return OK.getCommand();
				} catch (MessageDeleteException e) {
					return ERR.getCommand(e.getMessage());
				}
			}
			return OK.getCommand();
		default:
			break;
		}
		return "";
	}

}
