package rn.p1;


import rn.p1.pop3.client.Client; 
import rn.p1.pop3.server.Server;

public class Main {
	public static void main(String[] args) {
		Server server = new Server();
		server.start();
		
		Client client = new Client();
		client.start();
	}
}
